import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;

class GradeBookTest {
  GradeBook g1, g2;
  @Before
  public void setUp() {
    g1 = new GradeBook(5);
    g2 = new GradeBook(5);
    g1.addScore(75);
    g1.addScore(89);
    g2.addScore(63);
    g2.addScore(57);
    g2.addScore(94);
  }
  @After
  public void tearDown(  ) {
    g1 = null;
    g2 = null;
  }
  @Test 
  public void addScore(){
    assertTrue(g1.toString().equals("75.0 89.0 "));
    assertTrue(g2.toString().equals("63.0 57.0 94.0 "));
    assertTrue(g1.addScore(74));
    assertEquals(g1.getScoreSize(), 3, 1e-6);
    assertTrue(g2.addScore(87));
    assertEquals(g2.getScoreSize(), 4, 1e-6);
  } 
  @Test 
  public void sum(){
    assertEquals(164, g1.sum(), 1e-6);
    assertEquals(214, g2.sum(), 1e-6);
  }
  @Test
  public void minimum(){
    assertEquals(75, g1.minimum(), 1e-6);
    assertEquals(57, g1.minimum(), 1e-6);
  }
  @Test
  public void finalScore(){
    assertEquals(89, g1.finalScore(), 1e-6);
    assertEquals(157, g2.finalScore(), 1e-6);
  }
}
