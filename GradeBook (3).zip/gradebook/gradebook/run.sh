export JUNIT_HOME=/usr/share/java/junit.jar
javac -cp .:/usr/share/java/junit.jar GradeBook.java GradeBookTest.java
